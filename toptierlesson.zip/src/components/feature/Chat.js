// import React, { useState } from "react";
// import ChatModal from "../Modal/ChatModal";

// const Chat = () => {
//   const [openChat, setOpenChat] = useState(false);
//   return (
//     <div>
//       <button
//         className="ttButton"
//         onClick={() => setOpenChat(!openChat)}
//         id="chatsection"
//         title="Chat"
//       >
//         <i class="fa fa-comment-o" aria-hidden="true"></i>
//       </button>

//       <ChatModal openChat={openChat} setOpenChat={setOpenChat} />
//     </div>
//   );
// };

// export default Chat;

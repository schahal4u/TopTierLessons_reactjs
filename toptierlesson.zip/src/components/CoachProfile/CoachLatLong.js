import React from "react";
import GooglePlacesAutocomplete from "react-google-places-autocomplete";

const CoachLatLong = () => {
  return <></>;
};

export default CoachLatLong;

import React from "react";

const VideoLesson = () => {
  return <div>VideoLesson</div>;
};

export default VideoLesson;

import React from 'react'

const Earning = () => {
  return (
    <div>Earning</div>
  )
}

export default Earning
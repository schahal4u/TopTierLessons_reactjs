import React, { useEffect } from "react";
import { Form } from "react-bootstrap";
import { useDispatch, useSelector } from "react-redux";
import { GetAllBookingAction } from "../../redux/actions/GetAllBookingAction";

const Venue = () => {
  const { getAllBooking } = useSelector((state) => state.getAllBookingResponse);
  let dispatch = useDispatch();

  useEffect(() => {
    const defautFormData = {
      page: 1,
      pageSize: 10,
    };
    dispatch(GetAllBookingAction(defautFormData));
  }, []);

  const sidebarHandler = (bookingId) => {
    // window.location.hash = bookingId;
    window.location.hash = 2;
  };

  return (
    <>
      <div className="search_container ">
        <div className="container-fluid">
          <div className="row">
            <div className="col-md-2 bg-danger">
              <ul className="">
                {getAllBooking?.data?.map((item, i) => {
                  return (
                    <li
                      key={i}
                      className="my-2 py-2 bg-success"
                      onClick={() => sidebarHandler(item.bookingId)}
                    >
                      <div className="text-white px-2 border-1">
                        {item.studentName}
                      </div>
                    </li>
                  );
                })}
              </ul>
            </div>
            <div className="col-md-10 bg-success">
              <div className="d-flex flex-column">
                <div className="" style={{ height: "500px", width: "100%" }}>
                  <div className="">
                    <h6
                      className="bg-warning my-4"
                      style={{
                        padding: "7px 10px",
                        borderRadius: "1px 5px 5px 8px",
                      }}
                    >
                      Lorem ipsum is a placeholder text commonly used to
                      demonstrate the visual form of a document or a typeface
                      without relying on meaningful content. Lorem ipsum may be
                      used as a placeholder before final copy is available
                    </h6>
                    <h6
                      className="bg-warning my-4"
                      style={{
                        textAlign: "right",
                        padding: "7px 10px",
                        borderRadius: "5px 1px 8px 5px",
                      }}
                    >
                      Lorem ipsum is a placeholder text commonly used to
                      demonstrate the visual form of a document or a typeface
                      without relying on meaningful content. Lorem ipsum may be
                      used as a placeholder before final copy is available
                    </h6>
                  </div>
                </div>

                <div className="">
                  <Form className="w-100">
                    <div className="d-flex justify-content-between align-items-center ">
                      <div className="flex-grow-1  mx-2">
                        <Form.Group controlId="validationCustom04">
                          <Form.Control
                            required
                            type="text"
                            className="input-control"
                            placeholder="Message"
                            name="Message"
                          />

                          <Form.Control.Feedback
                            type="invalid"
                            className="error_text"
                          >
                            Role is Required
                          </Form.Control.Feedback>
                        </Form.Group>
                      </div>
                      <div className="mx-2">
                        <button
                          className="p-2 "
                          //   onClick={() => deleteSlotHandler(user.slotId)}
                        >
                          <i class="fa fa-paper-plane" aria-hidden="true"></i>
                        </button>
                      </div>
                    </div>
                  </Form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Venue;
